using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BESTPET_DEFINITIVO.Pages
{
    public class NosotrosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
