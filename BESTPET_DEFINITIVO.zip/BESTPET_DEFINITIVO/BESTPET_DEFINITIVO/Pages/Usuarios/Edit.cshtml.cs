using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using BESTPET_DEFINITIVO.Data;
using BESTPET_DEFINITIVO.Models;

namespace BESTPET_DEFINITIVO.Pages.Usuarios
{
    public class EditModel : PageModel
    {
        private readonly AppDbContext _context;
        private readonly IWebHostEnvironment _webHostEnvironment;

        public EditModel(AppDbContext context, IWebHostEnvironment webHostEnvironment)
        {
            _context = context;
            _webHostEnvironment = webHostEnvironment;
        }

        [BindProperty]
        public Usuario Usuario { get; set; } = default!;

        [BindProperty]
        public IFormFile? FotoPerfil { get; set; }

        // --- NUEVA PROPIEDAD PARA RECIBIR EL ARCHIVO DE EXPERIENCIA ---
        [BindProperty]
        public IFormFile? ArchivoExperiencia { get; set; }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null) return NotFound();
            var usuario = await _context.Usuarios.FirstOrDefaultAsync(m => m.Id == id);
            if (usuario == null) return NotFound();

            Usuario = usuario;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            // Usamos el m�todo seguro para actualizar, protegiendo la contrase�a
            var userToUpdate = await _context.Usuarios.FindAsync(Usuario.Id);
            if (userToUpdate == null) return NotFound();

            userToUpdate.Nombre = Usuario.Nombre;
            userToUpdate.Apellido = Usuario.Apellido;
            userToUpdate.Documento = Usuario.Documento;
            userToUpdate.FechaNacimiento = Usuario.FechaNacimiento;
            userToUpdate.Celular = Usuario.Celular;
            userToUpdate.Correo = Usuario.Correo;

            // --- NUEVA L�GICA PARA ACTUALIZAR CAMPOS DE PASEADOR ---
            if (userToUpdate.Rol == "Paseador")
            {
                userToUpdate.Descripcion = Usuario.Descripcion;

                if (ArchivoExperiencia != null)
                {
                    string uniqueFileName = Guid.NewGuid().ToString() + "_" + ArchivoExperiencia.FileName;
                    string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "documentos/experiencia");
                    string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                    using (var fileStream = new FileStream(filePath, FileMode.Create))
                    {
                        await ArchivoExperiencia.CopyToAsync(fileStream);
                    }
                    userToUpdate.RutaArchivoExperiencia = "/documentos/experiencia/" + uniqueFileName;
                }
            }

            if (FotoPerfil != null)
            {
                string uniqueFileName = Guid.NewGuid().ToString() + "_" + FotoPerfil.FileName;
                string uploadsFolder = Path.Combine(_webHostEnvironment.WebRootPath, "imagenes/usuarios");
                string filePath = Path.Combine(uploadsFolder, uniqueFileName);
                userToUpdate.RutaFoto = "/imagenes/usuarios/" + uniqueFileName;
                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await FotoPerfil.CopyToAsync(fileStream);
                }
            }

            await _context.SaveChangesAsync();
            return RedirectToPage("/MiCuenta");
        }
    }
}