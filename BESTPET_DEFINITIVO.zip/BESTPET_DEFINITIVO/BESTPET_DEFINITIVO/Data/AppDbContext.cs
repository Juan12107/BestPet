﻿using Microsoft.EntityFrameworkCore;
using BESTPET_DEFINITIVO.Models;

namespace BESTPET_DEFINITIVO.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Usuario> Usuarios { get; set; }
        public DbSet<Mascota> Mascotas { get; set; }
    }
}
