﻿using Microsoft.EntityFrameworkCore;
using BESTPET_DEFINITIVO.Models;

namespace BESTPET_DEFINITIVO.Data
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new AppDbContext(
                serviceProvider.GetRequiredService<DbContextOptions<AppDbContext>>()))
            {
                // Si ya existe CUALQUIER usuario, no hace nada.
                if (context.Usuarios.Any())
                {
                    return;
                }

                // Si no hay usuarios, crea la cuenta de Administrador
                context.Usuarios.Add(
                    new Usuario
                    {
                        Nombre = "Admin",
                        Apellido = "BestPet",
                        Correo = "admin@bestpet.com",
                        Rol = "Admin",
                        PasswordHash = BCrypt.Net.BCrypt.HashPassword("admin123"), // Contraseña temporal
                        FechaRegistro = DateTime.Now,
                        Documento = "0000000",
                        Celular = "0000000"
                    }
                );
                context.SaveChanges();
            }
        }
    }
}