﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BESTPET_DEFINITIVO.Migrations
{
    /// <inheritdoc />
    public partial class FinalizarModelos : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Mascota_Usuarios_UsuarioId",
                table: "Mascota");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Mascota",
                table: "Mascota");

            migrationBuilder.RenameTable(
                name: "Mascota",
                newName: "Mascotas");

            migrationBuilder.RenameIndex(
                name: "IX_Mascota_UsuarioId",
                table: "Mascotas",
                newName: "IX_Mascotas_UsuarioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Mascotas",
                table: "Mascotas",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Mascotas_Usuarios_UsuarioId",
                table: "Mascotas",
                column: "UsuarioId",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Mascotas_Usuarios_UsuarioId",
                table: "Mascotas");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Mascotas",
                table: "Mascotas");

            migrationBuilder.RenameTable(
                name: "Mascotas",
                newName: "Mascota");

            migrationBuilder.RenameIndex(
                name: "IX_Mascotas_UsuarioId",
                table: "Mascota",
                newName: "IX_Mascota_UsuarioId");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Mascota",
                table: "Mascota",
                column: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Mascota_Usuarios_UsuarioId",
                table: "Mascota",
                column: "UsuarioId",
                principalTable: "Usuarios",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
