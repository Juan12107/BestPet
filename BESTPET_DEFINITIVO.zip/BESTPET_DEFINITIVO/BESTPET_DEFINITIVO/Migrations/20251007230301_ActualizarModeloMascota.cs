﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BESTPET_DEFINITIVO.Migrations
{
    /// <inheritdoc />
    public partial class ActualizarModeloMascota : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "Especie",
                table: "Mascotas",
                newName: "Genero");

            migrationBuilder.AddColumn<string>(
                name: "Recomendaciones",
                table: "Mascotas",
                type: "longtext",
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");

            migrationBuilder.AddColumn<string>(
                name: "Vacunas",
                table: "Mascotas",
                type: "longtext",
                nullable: true)
                .Annotation("MySql:CharSet", "utf8mb4");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Recomendaciones",
                table: "Mascotas");

            migrationBuilder.DropColumn(
                name: "Vacunas",
                table: "Mascotas");

            migrationBuilder.RenameColumn(
                name: "Genero",
                table: "Mascotas",
                newName: "Especie");
        }
    }
}
